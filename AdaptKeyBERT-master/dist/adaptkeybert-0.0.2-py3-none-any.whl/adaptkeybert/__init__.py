from adaptkeybert._model import KeyBERT

__version__ = "0.0.2"
__author__ = 'Aman Priyanshu'